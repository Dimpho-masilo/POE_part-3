/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package QuickChatApplication;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for Message class.
 * Part 2: message validation tests.
 * Part 3: array-based feature tests using rubric test data.
 */
public class MessageTest {

    private Message message1;
    private Message message2;

    @BeforeEach
    public void setUp() {
        // Reset all static arrays and counters before every test
        Message.sentCount           = 0;
        Message.disregardedCount    = 0;
        Message.storedCount         = 0;
        Message.totalMessagesSent   = 0;
        Message.sentMessages        = new String[100];
        Message.disregardedMessages = new String[100];
        Message.storedMessages      = new String[100];
        Message.messageHashes       = new String[100];
        Message.messageIDs          = new String[100];
        Message.messageRecipients   = new String[100];

        // ── POPULATE WITH RUBRIC TEST DATA ────────────────────────────────────
        // Message 1: Sent
        Message.sentMessages[0]      = "Did you get the cake?";
        Message.messageRecipients[0] = "+27834557896";
        Message.messageHashes[0]     = "00:1:DIDCAKE?";
        Message.messageIDs[0]        = "0000000001";

        // Message 2: Stored
        Message.storedMessages[0]    = "Where are you? You are late! I have asked you to be on time.";
        Message.messageHashes[1]     = "00:2:WHERETIME.";
        Message.messageIDs[1]        = "0000000002";

        // Message 3: Disregarded
        Message.disregardedMessages[0] = "Yahoooo, I am at your gate.";

        // Message 4: Sent - developer number 0838884567
        Message.sentMessages[1]      = "It is dinner time!";
        Message.messageRecipients[1] = "0838884567";
        Message.messageHashes[2]     = "00:4:ITTIME!";
        Message.messageIDs[2]        = "0838884567";

        // Message 5: Stored
        Message.storedMessages[1]    = "Ok, I am leaving without you.";

        // Set counters
        Message.sentCount        = 2;
        Message.disregardedCount = 1;
        Message.storedCount      = 2;

        // Create message objects for Part 2 tests
        message1 = new Message(1);
        message2 = new Message(2);
    }

    // ── PART 2 TESTS ──────────────────────────────────────────────────────────

    // Test 1: Message length - success
    @Test
    public void testMessageLengthSuccess() {
        String validMessage = "Hi Mike, can you join us for dinner tonight?";
        assertTrue(validMessage.length() <= 250, "Message ready to send.");
    }

    // Test 2: Message length - failure
    @Test
    public void testMessageLengthFailure() {
        String longMessage = "A".repeat(251);
        int excess = longMessage.length() - 250;
        assertFalse(longMessage.length() <= 250,
                "Message exceeds 250 characters by " + excess + "; please reduce the size.");
    }

    // Test 3: Recipient cell - success
    @Test
    public void testRecipientCellSuccess() {
        String result = message1.checkRecipientCell("+27718693002");
        assertEquals("Cell phone number successfully captured.", result);
    }

    // Test 4: Recipient cell - failure
    @Test
    public void testRecipientCellFailure() {
        String result = message2.checkRecipientCell("08575975889");
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            result
        );
    }

    // Test 5: Message hash correct for message 1
    @Test
    public void testMessageHashMessage1() {
        message1.setMessageText("Hi Mike, can you join us for dinner tonight?");
        String hash = message1.createMessageHash();
        assertNotNull(hash);
        assertEquals(hash.toUpperCase(), hash, "Hash should be all caps");
        assertTrue(hash.contains(":1:"), "Hash should contain message number 1");
        assertTrue(hash.endsWith("HITONIGHT?"), "Hash should end with HITONIGHT?");
    }

    // Test 6: Message hash correct for message 2
    @Test
    public void testMessageHashMessage2() {
        message2.setMessageText("Hi Keegan, did you receive the payment?");
        String hash = message2.createMessageHash();
        assertNotNull(hash);
        assertEquals(hash.toUpperCase(), hash, "Hash should be all caps");
        assertTrue(hash.contains(":2:"), "Hash should contain message number 2");
        assertTrue(hash.endsWith("HIPAYMENT?"), "Hash should end with HIPAYMENT?");
    }

    // Test 7: Message ID is exactly 10 characters
    @Test
    public void testMessageIDCreated() {
        String id = message1.getMessageID();
        assertNotNull(id, "Message ID generated: " + id);
        assertTrue(message1.checkMessageID(), "Message ID generated: " + id);
        assertEquals(10, id.length(), "Message ID should be exactly 10 characters");
    }

    // Test 8: sentMessage - Send
    @Test
    public void testSentMessageSend() {
        message1.setMessageText("Hi Mike, can you join us for dinner tonight?");
        message1.checkRecipientCell("+27718693002");
        message1.createMessageHash();
        assertEquals("Message successfully sent.", message1.sentMessage(0));
    }

    // Test 9: sentMessage - Disregard
    @Test
    public void testSentMessageDisregard() {
        assertEquals("Press 0 to delete the message", message1.sentMessage(1));
    }

    // Test 10: sentMessage - Store
    @Test
    public void testSentMessageStore() {
        message1.setMessageText("Hi Mike, can you join us for dinner tonight?");
        message1.checkRecipientCell("+27718693002");
        message1.createMessageHash();
        assertEquals("Message successfully stored.", message1.sentMessage(2));
    }

    // ── PART 3 TESTS ──────────────────────────────────────────────────────────

    // Test 11: Sent messages array correctly populated with test data messages 1-4
    @Test
    public void testSentMessagesArrayPopulated() {
        assertEquals("Did you get the cake?", Message.sentMessages[0]);
        assertEquals("It is dinner time!", Message.sentMessages[1]);
    }

    // Test 12: Display longest message from messages 1-4
    // Rubric expects: "Where are you? You are late! I have asked you to be on time."
    @Test
    public void testDisplayLongestMessage() {
        String longest = Message.displayLongestMessage();
        assertEquals(
            "Where are you? You are late! I have asked you to be on time.",
            longest
        );
    }

    // Test 13: Search by message ID 0838884567 (message 4)
    // Rubric expects: returns "It is dinner time!"
    @Test
    public void testSearchByMessageID() {
         Message.messageIDs[1] = "0838884567";
         String result = Message.searchByMessageID("0838884567");
         assertTrue(result.contains("It is dinner time!"),
             "Search by ID 0838884567 should return 'It is dinner time!'");
}

    // Test 14: Search all messages for recipient +27838884567
    // Rubric expects: messages sent/stored for that recipient
    @Test
    public void testSearchByRecipient() {
        // Add the stored message to sent array with this recipient
        Message.sentMessages[Message.sentCount]      = "Where are you? You are late! I have asked you to be on time.";
        Message.messageRecipients[Message.sentCount] = "+27838884567";
        Message.messageHashes[Message.sentCount]     = "00:2:WHERETIME.";
        Message.messageIDs[Message.sentCount]        = "0000000002";
        Message.sentCount++;

        Message.sentMessages[Message.sentCount]      = "Ok, I am leaving without you.";
        Message.messageRecipients[Message.sentCount] = "+27838884567";
        Message.messageHashes[Message.sentCount]     = "00:5:OKYOU.";
        Message.messageIDs[Message.sentCount]        = "0000000005";
        Message.sentCount++;

        String result = Message.searchByRecipient("+27838884567");
        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."),
                "Should find message 2 for this recipient");
        assertTrue(result.contains("Ok, I am leaving without you."),
                "Should find message 5 for this recipient");
    }

    // Test 15: Delete message 2 using its hash
    // Rubric expects: "Message: 'Where are you?...' successfully deleted."
    @Test
    public void testDeleteMessageByHash() {
       Message.sentMessages[Message.sentCount]      = "Where are you? You are late! I have asked you to be on time.";
       Message.messageRecipients[Message.sentCount] = "+27838884567";
       Message.messageHashes[Message.sentCount]     = "00:2:WHERETIME.";
       Message.messageIDs[Message.sentCount]        = "0000000002";
       Message.sentCount++;

    String result = Message.deleteMessageByHash("00:2:WHERETIME.");
    assertTrue(result.contains("successfully deleted"),
            "Should confirm deletion");
   
}
    // Test 16: Display report shows all required fields for sent and stored messages
    @Test
    public void testDisplayReport() {
        String report = Message.displayReport();
        assertTrue(report.contains("Message Hash"), "Report must contain Message Hash");
        assertTrue(report.contains("Recipient"),    "Report must contain Recipient");
        assertTrue(report.contains("Message"),      "Report must contain Message");
        assertTrue(report.contains("Did you get the cake?"),
                "Report must include sent message content");
        assertTrue(report.contains("Where are you? You are late! I have asked you to be on time."),
                "Report must include stored message content");
    }
}
