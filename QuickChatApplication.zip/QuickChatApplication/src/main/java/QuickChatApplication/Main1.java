/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QuickChatApplication;
import java.util.Scanner;
/**
 *
 * @author user
 */
public class Main1 {
    
        public static void main(String[] args) {

    
        Scanner inputDevice = new Scanner(System.in); // Scanner enables us to read input typed by the user in the console

       
        Login loginSystem = null;// Login object declared outside the loop so both case 1 and case 2 can access it

        System.out.println("===== WELCOME TO CHAT APP 2026 =====");

        // Loop keeps the menu running until the user chooses to exit
        while (true) {

            // ─── MAIN MENU ────────────────────────────────────────────────────
            // \n adds a blank line before the menu to keep output clean
            System.out.println("\nMain Menu:");
            System.out.println("1. Registration");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Select an option: ");

            // Read menu choice as a full line to avoid leftover newline bug
            String input = inputDevice.nextLine();

            // Declare choice variable before try/catch so switch can see it
            int choice;

            try {
                // Convert the string input to an integer
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                // Runs if user types letters instead of a number e.g. "abc"
                System.out.println("Invalid option. Please select 1, 2, or 3.");
                continue; // Skip back to the top of the while loop
            }

            switch (choice) {

                case 1: // ─── REGISTRATION ─────────────────────────────────────

                    System.out.println("\n===== REGISTRATION =====");

                    System.out.print("Enter first name: "); // Captures user's first name
                    String first = inputDevice.nextLine();

                    System.out.print("Enter last name: "); // Captures user's last name
                    String last = inputDevice.nextLine();

                    System.out.print("Enter username: "); // Captures user's username
                    String user = inputDevice.nextLine();

                    System.out.print("Enter password: "); // Captures user's password
                    String pass = inputDevice.nextLine();

                    System.out.print("Enter South African cell phone number (include +27): "); // Captures user's phone number
                    String phone = inputDevice.nextLine();

                    // Create Login object with the details we captured
                    loginSystem = new Login(first, last, user, pass, phone);

                    // Runs all validations and prints the result message
                    String registrationStatus = loginSystem.registerUser();
                    System.out.println(registrationStatus);

                    break;

                case 2: // ─── LOGIN ────────────────────────────────────────────

                    // Check if user has registered first
                    if (loginSystem == null) {
                        System.out.println("No account found. Please register first.");
                        break;
                    }

                    // Check if registration details were all valid
                    boolean userOK  = loginSystem.checkUserName();
                    boolean passOK  = loginSystem.checkPasswordComplexity();
                    boolean phoneOK = loginSystem.checkCellPhoneNumber();

                    if (!userOK || !passOK || !phoneOK) {
                        System.out.println("Registration was incomplete. Please register again.");
                        break;
                    }

                    System.out.println("\n===== LOGIN =====");

                    System.out.print("Enter username: ");
                    String loginUser = inputDevice.nextLine();

                    System.out.print("Enter password: ");
                    String loginPass = inputDevice.nextLine();

                    // Compare entered credentials against stored ones and print result
                    System.out.println(loginSystem.returnLoginStatus(loginUser, loginPass));

                    break;

                case 3: // ─── EXIT ─────────────────────────────────────────────

                    System.out.println("\nGoodbye! Thank you for using Chat App 2026.");
                    inputDevice.close(); // Release the Scanner resource
                    return;              // Exit the program completely

                default:
                    // Handles anything that is not 1, 2, or 3
                    System.out.println("Invalid option. Please select 1, 2, or 3.");
            }
        }
    }
}
    

