/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package QuickChatApplication;

import javax.swing.*;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;

/**
 * QuickChat Application - Main Class
 * Part 1: Registration and Login
 * Part 2: Send Messages with hash, store, disregard
 * Part 3: Stored Messages menu with array-based features
 */
public class QuickChatApplication {

    static String registeredUsername;
    static String registeredPassword;
    static String registeredPhone;
    static int totalMessagesSent = 0;
    static int messageNumber = 0;

    public static void main(String[] args) {
        // Display welcome message before registration
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
        registerUser();

        // If credentials correct, proceed to login
        if (loginUser()) {
            JOptionPane.showMessageDialog(null, "Login successful. Redirecting to QuickChat...");
            runMessageSystem();
        } else {
            JOptionPane.showMessageDialog(null, "Login Failed. Exiting app.");
        }
    }

    // Registers the user with validated username, password and phone number
    public static void registerUser() {
        boolean valid = false;
        while (!valid) {
            // Validates username: must contain _ and be max 5 characters
            registeredUsername = JOptionPane.showInputDialog("Create a username (must contain _ and max 5 chars):");
            if (!(registeredUsername.contains("_") && registeredUsername.length() <= 5)) {
                JOptionPane.showMessageDialog(null, "Invalid username.");
                continue;
            }
            // Validates password 
            registeredPassword = JOptionPane.showInputDialog("Create password (8+ chars, 1 capital, 1 number, 1 special):");
            if (!registeredPassword.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$")) {
                JOptionPane.showMessageDialog(null, "Invalid password.");
                continue;
            }
            // Validates South African cellphone number
            registeredPhone = JOptionPane.showInputDialog("Enter cellphone number (+27xxxxxxxxx):");
            if (!registeredPhone.matches("^\\+27\\d{9}$")) {
                JOptionPane.showMessageDialog(null, "Invalid phone number.");
                continue;
            }
            JOptionPane.showMessageDialog(null, "Registration successful!");
            valid = true;
        }
    }

    // Checks login credentials against the registered details
    public static boolean loginUser() {
        String user = JOptionPane.showInputDialog("Login - Enter your username:");
        String pass = JOptionPane.showInputDialog("Enter your password:");
        return user.equals(registeredUsername) && pass.equals(registeredPassword);
    }

    // Displays the main menu with 4 options including Stored Messages (Part 3)
    public static void runMessageSystem() {
        boolean keepRunning = true;
        while (keepRunning) {
            String[] options = {"Send Messages", "Coming Soon", "Stored Messages", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Main Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0 -> sendMessages();
                case 1 -> JOptionPane.showMessageDialog(null, "Coming soon.");
                case 2 -> storedMessagesMenu(); // Part 3 menu
                case 3 -> {
                    keepRunning = false;
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                }
            }
        }
    }

    // Allows the user to send multiple messages in one session
    public static void sendMessages() {
        int count = Integer.parseInt(
            JOptionPane.showInputDialog("How many messages would you like to send?"));

        for (int i = 0; i < count; i++) {
            messageNumber++;
            String messageID = generateMessageID();

            // Show generated message ID
            JOptionPane.showMessageDialog(null, "Message ID generated: " + messageID);

            // Validates recipient's South African number
            String recipient = JOptionPane.showInputDialog("Enter recipient number (+27xxxxxxxxx):");
            if (!recipient.matches("^\\+27\\d{9}$")) {
                JOptionPane.showMessageDialog(null, "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
                i--;
                messageNumber--;
                continue;
            }
            JOptionPane.showMessageDialog(null, "Cell phone number successfully captured.");

            // Limits message to 250 characters
            String message = JOptionPane.showInputDialog("Enter message (max 250 characters):");
            if (message.length() > 250) {
                JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters.");
                i--;
                messageNumber--;
                continue;
            }
            JOptionPane.showMessageDialog(null, "Message ready to send.");

            // Generate hash for this message
            String hash = generateMessageHash(messageID, messageNumber, message);

            // Allows the user to choose what to do with the message
            String[] actions = {"Send Message", "Disregard Message", "Store Message to send later"};
            int action = JOptionPane.showOptionDialog(null,
                    "What would you like to do with this message?", "Message Options",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, actions, actions[0]);

            switch (action) {
                case 0 -> {
                    // Add to sent parallel arrays
                    Message.sentMessages[Message.sentCount]      = message;
                    Message.messageHashes[Message.sentCount]     = hash;
                    Message.messageIDs[Message.sentCount]        = messageID;
                    Message.messageRecipients[Message.sentCount] = recipient;
                    Message.sentCount++;
                    totalMessagesSent++;
                    displayMessageDetails(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message successfully sent.");
                }
                case 1 -> {
                    // Add to disregarded array
                    Message.disregardedMessages[Message.disregardedCount] = message;
                    Message.disregardedCount++;
                    JOptionPane.showMessageDialog(null, "Press 0 to delete the message");
                }
                case 2 -> {
                    // Add to stored array and write to JSON
                    Message.storedMessages[Message.storedCount] = message;
                    Message.storedCount++;
                    writeMessageJSON(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message successfully stored.");
                }
            }
        }
        // Show total messages sent after all messages processed
        JOptionPane.showMessageDialog(null, "Total messages sent: " + totalMessagesSent);
    }

    // ── PART 3: STORED MESSAGES MENU ─────────────────────────────────────────
    public static void storedMessagesMenu() {
        // Load stored messages from JSON file into the storedMessages array

        String[] options = {
            "a. Display all sent messages",
            "b. Display longest message",
            "c. Search by Message ID",
            "d. Search by Recipient",
            "e. Delete message by Hash",
            "f. Display Report",
            "Back to Main Menu"
        };

        boolean inMenu = true;
        while (inMenu) {
            int choice = JOptionPane.showOptionDialog(null,
                    "Stored Messages - Choose a feature:",
                    "Stored Messages",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, options, options[0]);

            switch (choice) {
                // a. Display sender and recipient of all sent messages
                case 0 -> JOptionPane.showMessageDialog(null,
                        Message.displayAllSentMessages() + "\n" + Message.displayAllStoredMessages());

                // b. Display the longest message
                case 1 -> JOptionPane.showMessageDialog(null,
                        "Longest Message:\n" + Message.displayLongestMessage());

                // c. Search for a message by ID
                case 2 -> {
                    String id = JOptionPane.showInputDialog("Enter Message ID to search:");
                    JOptionPane.showMessageDialog(null, Message.searchByMessageID(id));
                }

                // d. Search all messages for a particular recipient
                case 3 -> {
                    String recipient = JOptionPane.showInputDialog("Enter recipient number to search:");
                    JOptionPane.showMessageDialog(null, Message.searchByRecipient(recipient));
                }

                // e. Delete a message using its hash
                case 4 -> {
                    String hash = JOptionPane.showInputDialog("Enter Message Hash to delete:");
                    JOptionPane.showMessageDialog(null, Message.deleteMessageByHash(hash));
                }

                // f. Display full report of all messages
                case 5 -> JOptionPane.showMessageDialog(null, Message.displayReport());

                // Back to main menu
                case 6 -> inMenu = false;
            }
        }
    }

    // Generates a random 10-digit message ID
    public static String generateMessageID() {
        return String.format("%010d", new Random().nextInt(1_000_000_000));
    }

    // Creates hash: first 2 digits of ID : message number : first+last word ALL CAPS
    public static String generateMessageHash(String id, int num, String msg) {
        String[] words = msg.trim().split(" ");
        String first = words[0];
        String last  = words[words.length - 1];
        return (id.substring(0, 2) + ":" + num + ":" + first + last).toUpperCase();
    }

    // Displays the full details of a sent message
    public static void displayMessageDetails(String id, String hash, String recipient, String message) {
        JOptionPane.showMessageDialog(null,
                "Message ID: "  + id        + "\n" +
                "Hash: "        + hash      + "\n" +
                "Recipient: "   + recipient + "\n" +
                "Message: "     + message);
    }

    // Writes a stored message to a JSON file
    public static void writeMessageJSON(String messageID, String hash, String recipient, String message) {
        StringBuilder jsonEntry = new StringBuilder();
        jsonEntry.append("{\n");
        jsonEntry.append("  \"MessageID\": \"").append(messageID).append("\",\n");
        jsonEntry.append("  \"MessageHash\": \"").append(hash).append("\",\n");
        jsonEntry.append("  \"Recipient\": \"").append(recipient).append("\",\n");
        jsonEntry.append("  \"Message\": \"").append(message.replace("\"", "\\\"")).append("\"\n");
        jsonEntry.append("},\n");
        try (FileWriter file = new FileWriter("message.json", true)) {
            file.write(jsonEntry.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file: " + e.getMessage());
        }
    }
}