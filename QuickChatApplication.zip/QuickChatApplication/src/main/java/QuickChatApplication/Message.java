/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QuickChatApplication;

import javax.swing.*;
import java.io.*;
import java.util.*;

/**
 * Message class for QuickChat Application.
 * Part 2: Message sending, hashing, storing.
 * Part 3: Parallel arrays and stored message features.
 */
public class Message {

    private String messageID;
    private String recipient;
    private String messageText;
    private String messageHash;
    private int messageNumber;

    // ── PARALLEL ARRAYS ───────────────────────────────────────────────────────
    // Contains all sent messages
    static String[] sentMessages        = new String[100];
    // Contains all disregarded messages
    static String[] disregardedMessages = new String[100];
    // Contains all stored messages - loaded from JSON file
    static String[] storedMessages      = new String[100];
    // Contains all message hashes
    static String[] messageHashes       = new String[100];
    // Contains all message IDs
    static String[] messageIDs          = new String[100];
    // Contains all recipients for sent messages
    static String[] messageRecipients   = new String[100];

    // Counters for each array
    static int sentCount        = 0;
    static int disregardedCount = 0;
    static int storedCount      = 0;
    static int totalMessagesSent = 0;

    static ArrayList<String> messageList = new ArrayList<>();

    // ── CONSTRUCTORS ──────────────────────────────────────────────────────────

    // Full constructor used by the main app
    public Message(String messageID, String recipient, String messageText, int messageNumber) {
        this.messageID     = messageID;
        this.recipient     = recipient;
        this.messageText   = messageText;
        this.messageNumber = messageNumber;
        this.messageHash   = createMessageHash();
    }

    // Constructor used by unit tests
    public Message(int messageNumber) {
        this.messageNumber = messageNumber;
        this.messageID     = String.format("%010d", new Random().nextInt(1_000_000_000));
    }

    // ── PART 2 METHODS ────────────────────────────────────────────────────────

    // Checks that the message ID is exactly 10 characters
    public boolean checkMessageID() {
        return messageID != null && messageID.length() == 10;
    }

    // Checks that the recipient cell number has +27 international code
    public String checkRecipientCell(String cell) {
        if (cell != null && cell.matches("^\\+27\\d{9}$")) {
            this.recipient = cell;
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // Creates and returns the message hash: XX:N:FIRSTLAST in ALL CAPS
    public String createMessageHash() {
        if (messageText == null || messageText.trim().isEmpty()) return "";
        String[] words = messageText.trim().split("\\s+");
        String first = words[0];
        String last  = words[words.length - 1];
        this.messageHash = (messageID.substring(0, 2) + ":" + messageNumber + ":" + first + last).toUpperCase();
        return this.messageHash;
    }

    // Allows user to send, disregard or store - populates the correct array
    public String sentMessage(int action) {
        switch (action) {
            case 0 -> {
                // Add to sent arrays
                sentMessages[sentCount]      = messageText;
                messageHashes[sentCount]     = messageHash;
                messageIDs[sentCount]        = messageID;
                messageRecipients[sentCount] = recipient;
                sentCount++;
                totalMessagesSent++;
                messageList.add(printMessages());
                return "Message successfully sent.";
            }
            case 1 -> {
                // Add to disregarded array
                disregardedMessages[disregardedCount] = messageText;
                disregardedCount++;
                return "Press 0 to delete the message";
            }
            case 2 -> {
                // Add to stored array and write to JSON
                storedMessages[storedCount]  = messageText;
                messageHashes[storedCount]   = messageHash;
                messageIDs[storedCount]      = messageID;
                storedCount++;
                storeMessage();
                return "Message successfully stored.";
            }
            default -> {
                return "No action taken.";
            }
        }
    }

    // Returns the message details as a formatted string
    public String printMessages() {
        return "Message ID: "  + messageID   + "\n" +
               "Hash: "        + messageHash + "\n" +
               "Recipient: "   + recipient   + "\n" +
               "Message: "     + messageText;
    }

    // Returns the total number of messages sent
    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    // Writes the message to a JSON file for storage
    public void storeMessage() {
        StringBuilder jsonEntry = new StringBuilder();
        jsonEntry.append("{\n");
        jsonEntry.append("  \"MessageID\": \"").append(messageID).append("\",\n");
        jsonEntry.append("  \"MessageHash\": \"").append(messageHash).append("\",\n");
        jsonEntry.append("  \"Recipient\": \"").append(recipient).append("\",\n");
        jsonEntry.append("  \"Message\": \"").append(messageText.replace("\"", "\\\"")).append("\"\n");
        jsonEntry.append("},\n");
        try (FileWriter file = new FileWriter("messages.json", true)) {
            file.write(jsonEntry.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing to file: " + e.getMessage());
        }
    }

    // ── PART 3: READ JSON FILE INTO STORED MESSAGES ARRAY ────────────────────
    // Reads the JSON file and loads stored messages into the storedMessages array
    public static void loadStoredMessagesFromJSON() {
        storedCount = 0; // Reset before loading
        storedMessages = new String[100];
        File file = new File("messages.json");
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                // Extract the Message value from each JSON line
                if (line.startsWith("\"Message\":")) {
                    String msg = line.replace("\"Message\":", "")
                                     .replace("\"", "")
                                     .replace(",", "")
                                     .trim();
                    if (!msg.isEmpty() && storedCount < 100) {
                        storedMessages[storedCount] = msg;
                        storedCount++;
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading JSON file: " + e.getMessage());
        }
    }

    // ── PART 3 FEATURE METHODS ────────────────────────────────────────────────

    // a. Returns the sender (recipient) and message for all sent messages
    public static String displayAllSentMessages() {
        if (sentCount == 0) return "No messages sent yet.";
        StringBuilder sb = new StringBuilder("--- All Sent Messages ---\n");
        for (int i = 0; i < sentCount; i++) {
            sb.append("\nRecipient: ").append(messageRecipients[i])
              .append("\nMessage: ").append(sentMessages[i])
              .append("\n");
        }
        return sb.toString();
    }
    
    // Returns all STORED messages
public static String displayAllStoredMessages() {
    if (storedCount == 0) return "No stored messages yet.";
    StringBuilder sb = new StringBuilder("--- All Stored Messages ---\n");
    for (int i = 0; i < storedCount; i++) {
        sb.append("\nMessage: ").append(storedMessages[i])
          .append("\n");
    }
    return sb.toString();
}

    // b. Searches parallel arrays and returns the longest message
    public static String displayLongestMessage() {
        String longest = "";
        // Search sent messages array
        for (int i = 0; i < sentCount; i++) {
            if (sentMessages[i] != null && sentMessages[i].length() > longest.length()) {
                longest = sentMessages[i];
            }
        }
        // Search stored messages array
        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i] != null && storedMessages[i].length() > longest.length()) {
                longest = storedMessages[i];
            }
        }
        if (longest.isEmpty()) return "No messages found.";
        return longest;
    }

    // c. Searches parallel arrays by message ID, returns recipient and message
    public static String searchByMessageID(String id) {
        for (int i = 0; i < sentCount; i++) {
            if (messageIDs[i] != null && messageIDs[i].equals(id)) {
                return messageRecipients[i] + "\n" + sentMessages[i];
            }
        }
        return "Message ID not found.";
    }

    // d. Searches ALL parallel arrays for messages for a particular recipient
    public static String searchByRecipient(String recipient) {
        StringBuilder sb = new StringBuilder();
        // Search sent messages array
        for (int i = 0; i < sentCount; i++) {
            if (messageRecipients[i] != null && messageRecipients[i].equals(recipient)) {
                sb.append(sentMessages[i]).append("\n");
            }
        }
        // Search stored messages array (loaded from JSON)
        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i] != null && !storedMessages[i].isEmpty()) {
                sb.append(storedMessages[i]).append("\n");
            }
        }
        if (sb.length() == 0) return "No messages found for this recipient.";
        return sb.toString().trim();
    }

    // e. Searches parallel arrays and deletes a message using its hash
    public static String deleteMessageByHash(String hash) {
        for (int i = 0; i < sentCount; i++) {
            if (messageHashes[i] != null && messageHashes[i].equals(hash)) {
                String deletedMessage = sentMessages[i];
                // Shift remaining elements left to fill the gap
                for (int j = i; j < sentCount - 1; j++) {
                    sentMessages[j]      = sentMessages[j + 1];
                    messageHashes[j]     = messageHashes[j + 1];
                    messageIDs[j]        = messageIDs[j + 1];
                    messageRecipients[j] = messageRecipients[j + 1];
                }
                // Clear the last slot
                sentMessages[sentCount - 1]      = null;
                messageHashes[sentCount - 1]     = null;
                messageIDs[sentCount - 1]        = null;
                messageRecipients[sentCount - 1] = null;
                sentCount--;
                return "Message: \"" + deletedMessage + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }

    // f. Displays a full report of ALL messages: sent and stored
    public static String displayReport() {
        if (sentCount == 0 && storedCount == 0) return "No messages to report.";
        StringBuilder sb = new StringBuilder("--- Message Report ---\n");

        // Show all sent messages
        if (sentCount > 0) {
            sb.append("\n-- Sent Messages --\n");
            for (int i = 0; i < sentCount; i++) {
                sb.append("\nMessage Hash: ").append(messageHashes[i])
                  .append("\nRecipient: ").append(messageRecipients[i])
                  .append("\nMessage: ").append(sentMessages[i])
                  .append("\n");
            }
        }

        // Show all stored messages
        if (storedCount > 0) {
            sb.append("\n-- Stored Messages --\n");
            for (int i = 0; i < storedCount; i++) {
                sb.append("\nMessage: ").append(storedMessages[i]).append("\n");
            }
        }

        return sb.toString();
    }

    //  GETTERS AND SETTERS 
    public String getMessageID()   { return messageID; }
    public String getRecipient()   { return recipient; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }
    public int getMessageNumber()  { return messageNumber; }

    public void setMessageText(String messageText) { this.messageText = messageText; }
    public void setRecipient(String recipient)     { this.recipient = recipient; }
}